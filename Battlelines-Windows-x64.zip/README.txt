Battlelines — A History Quiz (Windows x64)

Run Battlelines.exe. Keep the three DLL files beside the EXE.

Requirements:
- Windows 10 or later, 64-bit
- Microsoft Edge WebView2 Evergreen Runtime
- .NET Framework 4.8 (included with current Windows versions)

If the app reports that WebView2 is missing, install the Evergreen Runtime from:
https://developer.microsoft.com/microsoft-edge/webview2/

The quiz HTML, styles, and questions are embedded in the EXE. Wikipedia source links and Google Fonts need an internet connection.
