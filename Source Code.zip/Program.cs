using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace Battlelines
{
internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.Run(new QuizWindow());
    }
}

internal sealed class QuizWindow : Form
{
    private const string AppHost = "battlelines.local";
    private readonly WebView2 browser = new WebView2 { Dock = DockStyle.Fill };

    public QuizWindow()
    {
        Text = "Battlelines — A History Quiz";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(720, 540);
        Size = new Size(1120, 820);
        BackColor = Color.FromArgb(244, 240, 232);
        Controls.Add(browser);
        Shown += async (sender, args) => await StartQuizAsync();
    }

    private async Task StartQuizAsync()
    {
        try
        {
            string assetsFolder = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "Battlelines", "Web");
            Directory.CreateDirectory(assetsFolder);
            ExtractAsset("index.html", assetsFolder);
            ExtractAsset("app.js", assetsFolder);
            ExtractAsset("styles.css", assetsFolder);

            await browser.EnsureCoreWebView2Async();
            CoreWebView2 core = browser.CoreWebView2;
            core.Settings.AreDevToolsEnabled = false;
            core.Settings.IsStatusBarEnabled = false;
            core.Settings.IsZoomControlEnabled = true;
            core.SetVirtualHostNameToFolderMapping(
                AppHost, assetsFolder, CoreWebView2HostResourceAccessKind.Allow);
            core.NavigationStarting += (sender, args) =>
            {
                Uri uri;
                if (Uri.TryCreate(args.Uri, UriKind.Absolute, out uri) &&
                    !string.Equals(uri.Host, AppHost, StringComparison.OrdinalIgnoreCase))
                {
                    args.Cancel = true;
                    Process.Start(new ProcessStartInfo(args.Uri) { UseShellExecute = true });
                }
            };
            core.Navigate("https://" + AppHost + "/index.html");
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                this,
                "Battlelines could not start. Install the Microsoft Edge WebView2 Runtime and try again.\r\n\r\n" + ex.Message,
                "Battlelines startup error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            Close();
        }
    }

    private static void ExtractAsset(string fileName, string destinationFolder)
    {
        string resourceName = "Battlelines.Web." + fileName;
        Stream source = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName);
        if (source == null)
            throw new InvalidOperationException("Embedded app file not found: " + fileName);
        using (source)
        using (Stream destination = File.Create(Path.Combine(destinationFolder, fileName)))
            source.CopyTo(destination);
    }
}
}
