const questions = [
  { category: "people", era: "ancient", prompt: "Which Egyptian ruler was the last active pharaoh of ancient Egypt?", answers: ["Nefertiti", "Cleopatra VII", "Hatshepsut", "Arsinoe II"], correct: 1, fact: "Cleopatra VII ruled from 51 to 30 BCE. After her death, Egypt became a province of the Roman Empire." },
  { category: "places", era: "ancient", prompt: "The ancient city of Petra, famous for its rock-cut architecture, was built by which people?", answers: ["The Nabataeans", "The Phoenicians", "The Hittites", "The Minoans"], correct: 0, fact: "The Nabataeans carved Petra into sandstone cliffs and made it a thriving trade center in present-day Jordan." },
  { category: "ideas", era: "medieval", prompt: "Which document, sealed in 1215, limited the English king’s power and influenced constitutional law?", answers: ["The Domesday Book", "The Magna Carta", "The Treaty of Paris", "The Bill of Rights"], correct: 1, fact: "Magna Carta was agreed by King John and rebel barons at Runnymede. Its legacy shaped ideas about the rule of law." },
  { category: "people", era: "early-modern", prompt: "Who published the heliocentric model arguing that Earth orbits the Sun in 1543?", answers: ["Galileo Galilei", "Johannes Kepler", "Nicolaus Copernicus", "Tycho Brahe"], correct: 2, fact: "Copernicus’s De revolutionibus orbium coelestium challenged the Earth-centered model dominant in Europe for centuries." },
  { category: "ideas", era: "modern", prompt: "In which year did the first powered, controlled flight by the Wright brothers take place?", answers: ["1899", "1903", "1908", "1912"], correct: 1, fact: "On December 17, 1903, Orville Wright piloted the Flyer for 12 seconds near Kitty Hawk, North Carolina." },
  { category: "places", era: "medieval", prompt: "Which West African city became a renowned center of learning and trade under the Mali Empire?", answers: ["Timbuktu", "Aksum", "Gao", "Mombasa"], correct: 0, fact: "Timbuktu grew into a major scholarly center, with the Sankore madrasah and libraries attracting students from across the region." },
  { category: "people", era: "modern", prompt: "Who became the first woman to win a Nobel Prize, honored for her research on radioactivity?", answers: ["Lise Meitner", "Ada Lovelace", "Marie Curie", "Dorothy Hodgkin"], correct: 2, fact: "Marie Curie received the 1903 Nobel Prize in Physics and later the 1911 Nobel Prize in Chemistry." },
  { category: "ideas", era: "early-modern", prompt: "Which invention is Johannes Gutenberg best known for introducing to Europe around 1450?", answers: ["The telescope", "The mechanical clock", "The movable-type printing press", "The spinning wheel"], correct: 2, fact: "Gutenberg’s press helped books and ideas circulate more widely across Europe, transforming communication." },
  { category: "places", era: "modern", prompt: "The ancient Inca citadel Machu Picchu is located in which modern-day country?", answers: ["Bolivia", "Peru", "Ecuador", "Chile"], correct: 1, fact: "Machu Picchu sits high in the Andes of Peru. It was built in the 15th century and brought to wider international attention in 1911." },
  { category: "people", era: "medieval", prompt: "Which Mali emperor made a famous pilgrimage to Mecca in 1324?", answers: ["Sundiata Keita", "Askia Muhammad", "Mansa Musa", "Sunni Ali"], correct: 2, fact: "Mansa Musa’s pilgrimage, accompanied by a large entourage, displayed the wealth and influence of the Mali Empire." },
  { category: "ideas", era: "early-modern", prompt: "The Napoleonic Wars are generally dated from which years?", answers: ["1789–1799", "1792–1802", "1803–1815", "1815–1830"], correct: 2, fact: "The wars began in 1803 and ended in 1815, spanning a series of conflicts between France and shifting European coalitions.", source: "https://en.wikipedia.org/wiki/Napoleonic_Wars" },
  { category: "places", era: "early-modern", prompt: "At which 1815 battle was Napoleon finally defeated after returning from exile?", answers: ["Austerlitz", "Leipzig", "Waterloo", "Trafalgar"], correct: 2, fact: "The Seventh Coalition defeated Napoleon at Waterloo in June 1815, ending his return to power.", source: "https://en.wikipedia.org/wiki/Napoleonic_Wars" },
  { category: "people", era: "early-modern", prompt: "After his first abdication in 1814, to which island was Napoleon exiled?", answers: ["Corsica", "Elba", "Saint Helena", "Sardinia"], correct: 1, fact: "Napoleon was exiled to Elba in 1814. He escaped in February 1815 and returned to France for the Hundred Days.", source: "https://en.wikipedia.org/wiki/Napoleonic_Wars" },
  { category: "ideas", era: "early-modern", prompt: "What was Napoleon’s economic policy intended to weaken Britain by restricting trade?", answers: ["The Continental System", "The Treaty of Amiens", "The Zollverein", "The Corn Laws"], correct: 0, fact: "Napoleon’s Continental System aimed to isolate Britain economically. Russia later violated the restrictions, preceding France’s 1812 invasion.", source: "https://en.wikipedia.org/wiki/Napoleonic_Wars" },
  { category: "places", era: "early-modern", prompt: "Which battle in October 1813 was a major defeat for Napoleon’s forces in the War of the Sixth Coalition?", answers: ["Wagram", "Jena-Auerstedt", "Leipzig", "Marengo"], correct: 2, fact: "The Sixth Coalition defeated Napoleon at Leipzig in October 1813, then advanced into France and captured Paris in 1814.", source: "https://en.wikipedia.org/wiki/Napoleonic_Wars" },
  { category: "ideas", era: "modern", prompt: "Which years are commonly given for World War I?", answers: ["1905–1909", "1914–1918", "1917–1921", "1939–1945"], correct: 1, fact: "World War I began in 1914 and the armistice ending the fighting took effect on 11 November 1918.", source: "https://en.wikipedia.org/wiki/World_War_I" },
  { category: "people", era: "modern", prompt: "Who was assassinated in Sarajevo in June 1914, helping trigger the July Crisis?", answers: ["Kaiser Wilhelm II", "Archduke Franz Ferdinand", "Tsar Nicholas II", "Woodrow Wilson"], correct: 1, fact: "The assassination of Austro-Hungarian heir Franz Ferdinand by Gavrilo Princip was followed by escalating declarations of war.", source: "https://en.wikipedia.org/wiki/World_War_I" },
  { category: "ideas", era: "modern", prompt: "In which year did the United States enter World War I on the Allied side?", answers: ["1914", "1915", "1917", "1918"], correct: 2, fact: "The United States joined the Allies in 1917, after Germany resumed unrestricted submarine warfare.", source: "https://en.wikipedia.org/wiki/World_War_I" },
  { category: "places", era: "modern", prompt: "Which battle became a symbol of the prolonged fighting and immense losses on the Western Front in 1916?", answers: ["Verdun", "Tannenberg", "Gallipoli", "Caporetto"], correct: 0, fact: "The Battle of Verdun was one of the major battles on the Western Front in 1916.", source: "https://en.wikipedia.org/wiki/World_War_I" },
  { category: "ideas", era: "modern", prompt: "What agreement brought the fighting in World War I to a halt on 11 November 1918?", answers: ["Treaty of Versailles", "Armistice of 11 November 1918", "Treaty of Brest-Litovsk", "Treaty of Trianon"], correct: 1, fact: "The armistice took effect on 11 November 1918. The Treaty of Versailles was a later peace settlement with Germany.", source: "https://en.wikipedia.org/wiki/World_War_I" },
  { category: "places", era: "modern", prompt: "Germany’s invasion of which country began World War II in Europe in September 1939?", answers: ["Belgium", "Poland", "France", "Norway"], correct: 1, fact: "Germany invaded Poland on 1 September 1939; Britain and France declared war on Germany two days later.", source: "https://en.wikipedia.org/wiki/World_War_II" },
  { category: "places", era: "modern", prompt: "The Allied D-Day landings in June 1944 took place in which region of France?", answers: ["Brittany", "Normandy", "Provence", "Alsace"], correct: 1, fact: "The Western Allies invaded France at Normandy in 1944, opening a new front in western Europe.", source: "https://en.wikipedia.org/wiki/World_War_II" },
  { category: "ideas", era: "modern", prompt: "Which attack in December 1941 led the United States to enter World War II?", answers: ["The Battle of Midway", "The invasion of Poland", "The attack on Pearl Harbor", "The Battle of Britain"], correct: 2, fact: "Japan attacked Pearl Harbor and other American and British territories in December 1941; the United States then entered the war against the Axis.", source: "https://en.wikipedia.org/wiki/World_War_II" },
  { category: "ideas", era: "modern", prompt: "On what date did Germany’s unconditional surrender in Europe take effect?", answers: ["6 June 1944", "8 May 1945", "15 August 1945", "2 September 1945"], correct: 1, fact: "Germany’s unconditional surrender took effect on 8 May 1945, often marked as Victory in Europe Day.", source: "https://en.wikipedia.org/wiki/World_War_II" },
  { category: "ideas", era: "modern", prompt: "On what date did Japan sign the formal surrender document that ended World War II?", answers: ["8 May 1945", "15 August 1945", "2 September 1945", "11 November 1945"], correct: 2, fact: "Japan announced its surrender in August 1945 and signed the formal surrender document on 2 September 1945.", source: "https://en.wikipedia.org/wiki/World_War_II" }
];

const topicNames = {
  war1812: "War of 1812", latinIndependence: "Latin American independence", greekIndependence: "Greek War of Independence",
  firstOpium: "First Opium War", mexicanAmerican: "Mexican–American War", taiping: "Taiping Rebellion", crimean: "Crimean War",
  secondOpium: "Second Opium War", indianRebellion: "Indian Rebellion of 1857", americanCivil: "American Civil War",
  francoPrussian: "Franco-Prussian War", russoTurkish: "Russo-Turkish War", pacific: "War of the Pacific",
  sinoJapanese1: "First Sino-Japanese War", spanishAmerican: "Spanish-American War", russoJapanese: "Russo-Japanese War",
  russianCivil: "Russian Civil War", chineseCivil: "Chinese Civil War", spanishCivil: "Spanish Civil War", sinoJapanese2: "Second Sino-Japanese War",
  firstIndochina: "First Indochina War", indiaPakistan1965: "India–Pakistan War of 1965", sixDay: "Six-Day War", arabIsraeli: "Arab–Israeli conflict",
  koreanWar: "Korean War", algerianWar: "Algerian War", vietnamWar: "Vietnam War", sinoIndian: "Sino-Indian War",
  sovietAfghan: "Soviet–Afghan War", iranIraq: "Iran–Iraq War", falklands: "Falklands War",
  gulfWar1991: "Gulf War", yugoslavWars: "Yugoslav Wars", congoWars: "Congo Wars", kargilWar: "Kargil War",
  afghanistan2001: "War in Afghanistan (2001–2021)", iraqWar2003: "Iraq War", russoGeorgian: "Russo-Georgian War", syrianCivil: "Syrian Civil War"
};

const additionalQuestions = [
  { topic: "war1812", category: "ideas", era: "early-modern", prompt: "Which two countries fought the War of 1812?", answers: ["United States and Britain", "United States and France", "Mexico and Spain", "Russia and Sweden"], correct: 0, fact: "The United States fought Britain and its North American colonies; Indigenous nations also played major roles on both sides.", source: "https://en.wikipedia.org/wiki/War_of_1812" },
  { topic: "war1812", category: "ideas", era: "early-modern", prompt: "Which treaty formally ended the War of 1812?", answers: ["Treaty of Ghent", "Treaty of Paris", "Treaty of Versailles", "Treaty of Utrecht"], correct: 0, fact: "The United States and Britain signed the Treaty of Ghent in December 1814. It largely restored prewar boundaries.", source: "https://en.wikipedia.org/wiki/War_of_1812" },
  { topic: "war1812", category: "places", era: "early-modern", prompt: "Which U.S. capital city did British forces burn in 1814?", answers: ["Philadelphia", "Washington", "New York", "Boston"], correct: 1, fact: "British troops burned public buildings in Washington, including the Capitol and the President’s House, during the Chesapeake campaign.", source: "https://en.wikipedia.org/wiki/War_of_1812" },

  { topic: "latinIndependence", category: "places", era: "early-modern", prompt: "Which former French colony became independent as Haiti after the Haitian Revolution?", answers: ["Cuba", "Saint-Domingue", "Brazil", "New Granada"], correct: 1, fact: "The Haitian Revolution (1791–1804) ended French rule in Saint-Domingue and created independent Haiti.", source: "https://en.wikipedia.org/wiki/Latin_American_wars_of_independence" },
  { topic: "latinIndependence", category: "ideas", era: "early-modern", prompt: "The Spanish American wars of independence primarily sought to end colonial rule by which empire?", answers: ["Portuguese Empire", "Spanish Empire", "French Empire", "British Empire"], correct: 1, fact: "The conflicts from 1808 to 1833 led most of Spain’s American colonies to independence.", source: "https://en.wikipedia.org/wiki/Latin_American_wars_of_independence" },
  { topic: "latinIndependence", category: "places", era: "early-modern", prompt: "Which country separated from the Portuguese Empire through the Brazilian War of Independence?", answers: ["Argentina", "Brazil", "Chile", "Mexico"], correct: 1, fact: "The Brazilian War of Independence (1821–1824) resulted in Brazil separating from Portugal.", source: "https://en.wikipedia.org/wiki/Latin_American_wars_of_independence" },

  { topic: "greekIndependence", category: "ideas", era: "early-modern", prompt: "Which empire did Greek revolutionaries fight to leave during the Greek War of Independence?", answers: ["Austrian Empire", "Ottoman Empire", "Russian Empire", "French Empire"], correct: 1, fact: "The Greek uprising sought independence from Ottoman rule and began in 1821.", source: "https://en.wikipedia.org/wiki/Greek_War_of_Independence" },
  { topic: "greekIndependence", category: "places", era: "early-modern", prompt: "Which 1827 naval battle saw Britain, France, and Russia defeat an Ottoman-Egyptian fleet?", answers: ["Navarino", "Lepanto", "Sinope", "Trafalgar"], correct: 0, fact: "The Battle of Navarino was a major turning point in foreign intervention in the Greek struggle.", source: "https://en.wikipedia.org/wiki/Greek_War_of_Independence" },
  { topic: "greekIndependence", category: "people", era: "early-modern", prompt: "Which British poet and philhellene died in Greece while supporting its independence struggle?", answers: ["John Keats", "Lord Byron", "Percy Bysshe Shelley", "William Wordsworth"], correct: 1, fact: "Lord Byron joined the Greek cause and died at Missolonghi in 1824.", source: "https://en.wikipedia.org/wiki/Greek_War_of_Independence" },

  { topic: "firstOpium", category: "ideas", era: "modern", prompt: "Which two powers fought the First Opium War (1839–1842)?", answers: ["Britain and Qing China", "France and Japan", "Russia and Persia", "Portugal and India"], correct: 0, fact: "The war arose amid disputes over trade and opium, pitting Britain against the Qing dynasty.", source: "https://en.wikipedia.org/wiki/First_Opium_War" },
  { topic: "firstOpium", category: "people", era: "modern", prompt: "Which Qing official led the campaign to suppress the opium trade in Canton in 1839?", answers: ["Lin Zexu", "Zeng Guofan", "Hong Xiuquan", "Li Hongzhang"], correct: 0, fact: "Lin Zexu confiscated and destroyed large stocks of opium at Humen, escalating tensions with Britain.", source: "https://en.wikipedia.org/wiki/First_Opium_War" },
  { topic: "firstOpium", category: "ideas", era: "modern", prompt: "Which 1842 treaty ended the First Opium War?", answers: ["Treaty of Nanking", "Treaty of Tianjin", "Treaty of Shimonoseki", "Treaty of Portsmouth"], correct: 0, fact: "The Treaty of Nanking ended the war and required Qing China to cede Hong Kong Island to Britain, among other terms.", source: "https://en.wikipedia.org/wiki/First_Opium_War" },

  { topic: "mexicanAmerican", category: "ideas", era: "modern", prompt: "Which two countries fought the Mexican–American War of 1846–1848?", answers: ["Mexico and the United States", "Mexico and France", "Spain and the United States", "Mexico and Britain"], correct: 0, fact: "The war followed disputes over Texas and the U.S.–Mexican border, and ended with U.S. victory.", source: "https://en.wikipedia.org/wiki/Mexican%E2%80%93American_War" },
  { topic: "mexicanAmerican", category: "places", era: "modern", prompt: "Which treaty ended the Mexican–American War in 1848?", answers: ["Treaty of Guadalupe Hidalgo", "Treaty of Córdoba", "Treaty of Paris", "Treaty of Velasco"], correct: 0, fact: "Under the Treaty of Guadalupe Hidalgo, Mexico recognized the Rio Grande boundary and ceded a large northern territory to the United States.", source: "https://en.wikipedia.org/wiki/Mexican%E2%80%93American_War" },
  { topic: "mexicanAmerican", category: "people", era: "modern", prompt: "Who was the U.S. president during the Mexican–American War?", answers: ["James K. Polk", "Andrew Jackson", "Abraham Lincoln", "Zachary Taylor"], correct: 0, fact: "President James K. Polk pursued expansion and asked Congress for a declaration of war in 1846.", source: "https://en.wikipedia.org/wiki/Mexican%E2%80%93American_War" },

  { topic: "taiping", category: "people", era: "modern", prompt: "Who founded the Taiping Heavenly Kingdom and led the Taiping Rebellion?", answers: ["Hong Xiuquan", "Sun Yat-sen", "Yuan Shikai", "Zeng Guofan"], correct: 0, fact: "Hong Xiuquan led the Taiping movement, which challenged Qing rule from 1850 to 1864.", source: "https://en.wikipedia.org/wiki/Taiping_Rebellion" },
  { topic: "taiping", category: "places", era: "modern", prompt: "Which city did the Taiping rebels capture and make their capital, renaming it Tianjing?", answers: ["Beijing", "Nanjing", "Shanghai", "Wuhan"], correct: 1, fact: "The Taipings took Nanjing in 1853 and made it the capital of their Heavenly Kingdom.", source: "https://en.wikipedia.org/wiki/Taiping_Rebellion" },
  { topic: "taiping", category: "ideas", era: "modern", prompt: "Which ruling dynasty ultimately defeated the Taiping Rebellion?", answers: ["Ming dynasty", "Qing dynasty", "Han dynasty", "Tang dynasty"], correct: 1, fact: "Qing forces, assisted at different times by regional armies and foreign support, recaptured Nanjing in 1864.", source: "https://en.wikipedia.org/wiki/Taiping_Rebellion" },

  { topic: "crimean", category: "ideas", era: "modern", prompt: "Which empire fought Russia alongside Britain and France in the Crimean War?", answers: ["Ottoman Empire", "Mughal Empire", "Qing dynasty", "Spanish Empire"], correct: 0, fact: "The Ottoman Empire, Britain, France, and later Sardinia-Piedmont opposed Russia in the war of 1853–1856.", source: "https://en.wikipedia.org/wiki/Crimean_War" },
  { topic: "crimean", category: "places", era: "modern", prompt: "Which Crimean port city was the focus of a prolonged siege during the war?", answers: ["Odessa", "Sevastopol", "Istanbul", "Varna"], correct: 1, fact: "The Siege of Sevastopol lasted from 1854 to 1855 and ended with Russian forces abandoning the city.", source: "https://en.wikipedia.org/wiki/Crimean_War" },
  { topic: "crimean", category: "ideas", era: "modern", prompt: "Which 1856 treaty concluded the Crimean War?", answers: ["Treaty of Paris", "Treaty of Berlin", "Treaty of San Stefano", "Treaty of Adrianople"], correct: 0, fact: "The Treaty of Paris ended the war and neutralized the Black Sea under its terms.", source: "https://en.wikipedia.org/wiki/Crimean_War" },

  { topic: "secondOpium", category: "ideas", era: "modern", prompt: "Which European powers fought Qing China in the Second Opium War?", answers: ["Britain and France", "Russia and Prussia", "Spain and Portugal", "Italy and Austria"], correct: 0, fact: "Britain and France fought the Qing dynasty in the conflict of 1856–1860.", source: "https://en.wikipedia.org/wiki/Second_Opium_War" },
  { topic: "secondOpium", category: "ideas", era: "modern", prompt: "Which pair of treaties imposed new terms on Qing China during the Second Opium War?", answers: ["Treaties of Tianjin and Convention of Peking", "Treaty of Nanking and Treaty of Paris", "Treaty of Portsmouth and Treaty of Shimonoseki", "Treaty of Ghent and Treaty of Amiens"], correct: 0, fact: "The Treaties of Tianjin and the Convention of Peking expanded foreign access and privileges in China.", source: "https://en.wikipedia.org/wiki/Second_Opium_War" },
  { topic: "secondOpium", category: "places", era: "modern", prompt: "Which imperial complex near Beijing was looted and burned by Anglo-French forces in 1860?", answers: ["Forbidden City", "Old Summer Palace", "Temple of Heaven", "Summer Palace at Chengde"], correct: 1, fact: "The Old Summer Palace (Yuanmingyuan) was burned during the final phase of the war.", source: "https://en.wikipedia.org/wiki/Second_Opium_War" },

  { topic: "indianRebellion", category: "ideas", era: "modern", prompt: "Where did the Indian Rebellion of 1857 begin with a major sepoy uprising in May?", answers: ["Meerut", "Bombay", "Madras", "Calcutta"], correct: 0, fact: "The uprising at Meerut on 10 May 1857 spread to Delhi and other parts of northern India.", source: "https://en.wikipedia.org/wiki/Indian_Rebellion_of_1857" },
  { topic: "indianRebellion", category: "people", era: "modern", prompt: "Which Mughal emperor was declared the symbolic leader of the 1857 rebellion?", answers: ["Akbar II", "Bahadur Shah Zafar", "Shah Alam II", "Aurangzeb"], correct: 1, fact: "Rebels proclaimed Bahadur Shah Zafar emperor, though his actual power was limited.", source: "https://en.wikipedia.org/wiki/Indian_Rebellion_of_1857" },
  { topic: "indianRebellion", category: "ideas", era: "modern", prompt: "What major change followed the suppression of the Indian Rebellion of 1857?", answers: ["The East India Company gained direct rule", "The British Crown took over rule in India", "India became independent", "The Mughal Empire was restored"], correct: 1, fact: "The Government of India Act 1858 transferred the Company's governing authority to the British Crown.", source: "https://en.wikipedia.org/wiki/Indian_Rebellion_of_1857" },

  { topic: "americanCivil", category: "ideas", era: "modern", prompt: "Which event marked the opening of the American Civil War in April 1861?", answers: ["Battle of Gettysburg", "Attack on Fort Sumter", "Emancipation Proclamation", "Appomattox surrender"], correct: 1, fact: "Confederate forces attacked Fort Sumter in Charleston Harbor, South Carolina, on 12 April 1861.", source: "https://en.wikipedia.org/wiki/American_Civil_War" },
  { topic: "americanCivil", category: "ideas", era: "modern", prompt: "Which side won the American Civil War?", answers: ["The Confederacy", "The Union", "Britain", "Neither side"], correct: 1, fact: "The Union victory preserved the United States and led to the abolition of slavery.", source: "https://en.wikipedia.org/wiki/American_Civil_War" },
  { topic: "americanCivil", category: "people", era: "modern", prompt: "To which Union general did Robert E. Lee surrender at Appomattox Court House in 1865?", answers: ["Ulysses S. Grant", "William T. Sherman", "George B. McClellan", "George G. Meade"], correct: 0, fact: "Lee surrendered the Army of Northern Virginia to Ulysses S. Grant on 9 April 1865.", source: "https://en.wikipedia.org/wiki/American_Civil_War" },

  { topic: "francoPrussian", category: "ideas", era: "modern", prompt: "Who declared war on whom at the start of the Franco-Prussian War in 1870?", answers: ["France declared war on Prussia", "Prussia declared war on Austria", "Spain declared war on France", "Russia declared war on Germany"], correct: 0, fact: "France declared war on Prussia in July 1870; the conflict ended in a Prussian and German victory in 1871.", source: "https://en.wikipedia.org/wiki/Franco-Prussian_War" },
  { topic: "francoPrussian", category: "places", era: "modern", prompt: "At which battle was Napoleon III captured by Prussian forces in 1870?", answers: ["Sedan", "Waterloo", "Austerlitz", "Metz"], correct: 0, fact: "The French defeat at Sedan led to Napoleon III's capture and the collapse of the Second French Empire.", source: "https://en.wikipedia.org/wiki/Franco-Prussian_War" },
  { topic: "francoPrussian", category: "ideas", era: "modern", prompt: "Which state was proclaimed in the Hall of Mirrors at Versailles in January 1871?", answers: ["Kingdom of Italy", "German Empire", "Austro-Hungarian Empire", "Third French Republic"], correct: 1, fact: "The German Empire was proclaimed at Versailles during the siege of Paris, before the war formally ended.", source: "https://en.wikipedia.org/wiki/Franco-Prussian_War" },

  { topic: "russoTurkish", category: "ideas", era: "modern", prompt: "Which two empires fought the Russo-Turkish War of 1877–1878?", answers: ["Russian and Ottoman empires", "Russian and Persian empires", "British and Ottoman empires", "Austrian and Russian empires"], correct: 0, fact: "Russia declared war on the Ottoman Empire in 1877 amid the Eastern Crisis and Balkan uprisings.", source: "https://en.wikipedia.org/wiki/Russo-Turkish_War_(1877%E2%80%931878)" },
  { topic: "russoTurkish", category: "ideas", era: "modern", prompt: "Which 1878 treaty first set out major postwar terms after Russia's victory over the Ottomans?", answers: ["Treaty of San Stefano", "Treaty of Ghent", "Treaty of Nanking", "Treaty of Frankfurt"], correct: 0, fact: "The Treaty of San Stefano was revised later that year at the Congress of Berlin under pressure from other Great Powers.", source: "https://en.wikipedia.org/wiki/Russo-Turkish_War_(1877%E2%80%931878)" },
  { topic: "russoTurkish", category: "places", era: "modern", prompt: "Which Balkan state was recognized as independent at the Congress of Berlin in 1878 after the war?", answers: ["Bulgaria", "Romania", "Serbia", "Montenegro"], correct: 1, fact: "The Congress of Berlin recognized Romania, Serbia, and Montenegro as independent; Bulgaria received autonomous status.", source: "https://en.wikipedia.org/wiki/Russo-Turkish_War_(1877%E2%80%931878)" },

  { topic: "pacific", category: "ideas", era: "modern", prompt: "Which three South American countries fought in the War of the Pacific?", answers: ["Chile against Peru and Bolivia", "Argentina against Brazil and Uruguay", "Ecuador against Colombia and Peru", "Chile against Argentina and Brazil"], correct: 0, fact: "Chile fought Peru and Bolivia from 1879 to 1884 in a war centered on the Pacific coast and mineral-rich territory.", source: "https://en.wikipedia.org/wiki/War_of_the_Pacific" },
  { topic: "pacific", category: "ideas", era: "modern", prompt: "Which resource-rich desert region was central to the causes of the War of the Pacific?", answers: ["Atacama Desert", "Patagonian Steppe", "Sonoran Desert", "Sahara"], correct: 0, fact: "Disputes over taxation and control of nitrate-rich territory in the Atacama region helped trigger the conflict.", source: "https://en.wikipedia.org/wiki/War_of_the_Pacific" },
  { topic: "pacific", category: "places", era: "modern", prompt: "Which treaty in 1883 ended hostilities between Chile and Peru in the War of the Pacific?", answers: ["Treaty of Ancón", "Treaty of Lima", "Treaty of Valparaíso", "Treaty of Santiago"], correct: 0, fact: "The Treaty of Ancón ceded Tarapacá to Chile; Bolivia's separate settlement with Chile came later.", source: "https://en.wikipedia.org/wiki/War_of_the_Pacific" },

  { topic: "sinoJapanese1", category: "ideas", era: "modern", prompt: "Which peninsula's political status was a central issue in the First Sino-Japanese War?", answers: ["Korean Peninsula", "Arabian Peninsula", "Iberian Peninsula", "Malay Peninsula"], correct: 0, fact: "The war of 1894–1895 grew from rival Chinese and Japanese influence in Korea.", source: "https://en.wikipedia.org/wiki/First_Sino-Japanese_War" },
  { topic: "sinoJapanese1", category: "ideas", era: "modern", prompt: "Which treaty ended the First Sino-Japanese War in 1895?", answers: ["Treaty of Shimonoseki", "Treaty of Nanking", "Treaty of Portsmouth", "Treaty of Tianjin"], correct: 0, fact: "The Treaty of Shimonoseki ended the war and recognized Korea's independence from Qing suzerainty, among other terms.", source: "https://en.wikipedia.org/wiki/First_Sino-Japanese_War" },
  { topic: "sinoJapanese1", category: "places", era: "modern", prompt: "Which island did Qing China cede to Japan in the Treaty of Shimonoseki?", answers: ["Taiwan", "Hainan", "Sakhalin", "Jeju"], correct: 0, fact: "Taiwan and the Pescadores were ceded to Japan under the treaty; the Liaodong Peninsula was later returned after foreign intervention.", source: "https://en.wikipedia.org/wiki/First_Sino-Japanese_War" },

  { topic: "spanishAmerican", category: "places", era: "modern", prompt: "Which Cuban port was the USS Maine visiting when it exploded in 1898?", answers: ["Havana", "Santiago de Cuba", "Manila", "San Juan"], correct: 0, fact: "The explosion of the USS Maine in Havana Harbor helped intensify the crisis between the United States and Spain.", source: "https://en.wikipedia.org/wiki/Spanish%E2%80%93American_War" },
  { topic: "spanishAmerican", category: "places", era: "modern", prompt: "Which major naval battle in 1898 took place in Manila Bay?", answers: ["Battle of Manila Bay", "Battle of Santiago de Cuba", "Battle of San Juan Hill", "Battle of Guam"], correct: 0, fact: "The U.S. Navy defeated the Spanish fleet at Manila Bay in the Philippines in May 1898.", source: "https://en.wikipedia.org/wiki/Spanish%E2%80%93American_War" },
  { topic: "spanishAmerican", category: "ideas", era: "modern", prompt: "Which 1898 treaty formally ended the Spanish-American War?", answers: ["Treaty of Paris", "Treaty of Versailles", "Treaty of Ghent", "Treaty of Guadalupe Hidalgo"], correct: 0, fact: "The Treaty of Paris ended the war; Spain relinquished claims to Cuba and ceded Puerto Rico, Guam, and the Philippines to the United States.", source: "https://en.wikipedia.org/wiki/Spanish%E2%80%93American_War" },

  { topic: "russoJapanese", category: "ideas", era: "modern", prompt: "Which two empires fought the Russo-Japanese War of 1904–1905?", answers: ["Russian and Japanese empires", "Chinese and Japanese empires", "British and Russian empires", "Korean and Chinese empires"], correct: 0, fact: "The war was fought over rival imperial interests in Manchuria and Korea, ending in a Japanese victory.", source: "https://en.wikipedia.org/wiki/Russo-Japanese_War" },
  { topic: "russoJapanese", category: "places", era: "modern", prompt: "Which 1905 naval battle destroyed much of Russia's Baltic Fleet?", answers: ["Tsushima", "Port Arthur", "Yalu River", "Yellow Sea"], correct: 0, fact: "Japan's decisive victory at the Battle of Tsushima helped force Russia to negotiate peace.", source: "https://en.wikipedia.org/wiki/Russo-Japanese_War" },
  { topic: "russoJapanese", category: "ideas", era: "modern", prompt: "Which U.S. president helped mediate the peace treaty ending the Russo-Japanese War?", answers: ["Theodore Roosevelt", "William McKinley", "Woodrow Wilson", "William Howard Taft"], correct: 0, fact: "The Treaty of Portsmouth was negotiated in the United States with Theodore Roosevelt's mediation; he received the 1906 Nobel Peace Prize.", source: "https://en.wikipedia.org/wiki/Russo-Japanese_War" },

  { topic: "russianCivil", category: "ideas", era: "modern", prompt: "Which two broad sides fought in the Russian Civil War?", answers: ["Reds and Whites", "Roundheads and Cavaliers", "Jacobins and Girondins", "Nationalists and Republicans"], correct: 0, fact: "The Bolshevik Red Army fought a range of anti-Bolshevik White forces and other movements after the 1917 revolutions.", source: "https://en.wikipedia.org/wiki/Russian_Civil_War" },
  { topic: "russianCivil", category: "people", era: "modern", prompt: "Who organized and led the Red Army during much of the Russian Civil War?", answers: ["Leon Trotsky", "Alexander Kerensky", "Vladimir Nabokov", "Pyotr Wrangel"], correct: 0, fact: "Leon Trotsky became the leading organizer of the Red Army, which secured Bolshevik victory in the main civil-war fronts.", source: "https://en.wikipedia.org/wiki/Russian_Civil_War" },
  { topic: "russianCivil", category: "ideas", era: "modern", prompt: "Which political movement emerged victorious from the Russian Civil War?", answers: ["Bolsheviks", "White movement", "Provisional Government", "Russian monarchy"], correct: 0, fact: "The Bolshevik victory consolidated Soviet power; the Union of Soviet Socialist Republics was formed in 1922.", source: "https://en.wikipedia.org/wiki/Russian_Civil_War" },

  { topic: "chineseCivil", category: "ideas", era: "modern", prompt: "Which two parties were the principal rivals in the Chinese Civil War?", answers: ["Chinese Communist Party and Kuomintang", "Qing dynasty and Ming dynasty", "Japan and Russia", "Nationalists and Republicans of Spain"], correct: 0, fact: "The Chinese Communist Party and the Kuomintang (Nationalist Party) fought in two main phases, with a pause during the war against Japan.", source: "https://en.wikipedia.org/wiki/Chinese_Civil_War" },
  { topic: "chineseCivil", category: "people", era: "modern", prompt: "Who led the Chinese Communist Party to victory in the second phase of the civil war?", answers: ["Mao Zedong", "Chiang Kai-shek", "Sun Yat-sen", "Yuan Shikai"], correct: 0, fact: "Mao Zedong proclaimed the People's Republic of China in 1949 after Communist forces won on the mainland.", source: "https://en.wikipedia.org/wiki/Chinese_Civil_War" },
  { topic: "chineseCivil", category: "places", era: "modern", prompt: "Where did many Kuomintang forces and the Republic of China government retreat after losing the mainland in 1949?", answers: ["Taiwan", "Hainan", "Hong Kong", "Singapore"], correct: 0, fact: "The Nationalist government retreated to Taiwan, while the People's Republic of China was established on the mainland.", source: "https://en.wikipedia.org/wiki/Chinese_Civil_War" },

  { topic: "spanishCivil", category: "ideas", era: "modern", prompt: "Which two broad factions fought in the Spanish Civil War?", answers: ["Republicans and Nationalists", "Reds and Whites", "Allies and Axis", "Royalists and Parliamentarians"], correct: 0, fact: "The war of 1936–1939 pitted the Republican government and its supporters against the Nationalist rebels.", source: "https://en.wikipedia.org/wiki/Spanish_Civil_War" },
  { topic: "spanishCivil", category: "people", era: "modern", prompt: "Who led the Nationalist forces to victory in the Spanish Civil War?", answers: ["Francisco Franco", "Manuel Azaña", "Juan Negrín", "Buenaventura Durruti"], correct: 0, fact: "Francisco Franco became dictator after the Nationalist victory in 1939 and remained in power until 1975.", source: "https://en.wikipedia.org/wiki/Spanish_Civil_War" },
  { topic: "spanishCivil", category: "ideas", era: "modern", prompt: "Which two fascist powers provided major military support to Franco's Nationalists?", answers: ["Germany and Italy", "Britain and France", "Japan and China", "United States and Canada"], correct: 0, fact: "Nazi Germany and Fascist Italy supported the Nationalists; the Soviet Union aided the Republican side.", source: "https://en.wikipedia.org/wiki/Spanish_Civil_War" },

  { topic: "sinoJapanese2", category: "ideas", era: "modern", prompt: "Which 1937 incident is commonly associated with the start of full-scale war between China and Japan?", answers: ["Marco Polo Bridge incident", "Mukden incident", "Xi'an incident", "Manchurian Incident"], correct: 0, fact: "The Marco Polo Bridge incident near Beijing in July 1937 preceded the full-scale Second Sino-Japanese War.", source: "https://en.wikipedia.org/wiki/Second_Sino-Japanese_War" },
  { topic: "sinoJapanese2", category: "places", era: "modern", prompt: "Which Chinese capital city fell to Japanese forces in 1937, followed by a mass killing of civilians and prisoners?", answers: ["Nanjing", "Chongqing", "Beijing", "Wuhan"], correct: 0, fact: "Japanese forces captured Nanjing in December 1937; the Nanjing Massacre followed.", source: "https://en.wikipedia.org/wiki/Second_Sino-Japanese_War" },
  { topic: "sinoJapanese2", category: "ideas", era: "modern", prompt: "When did the Second Sino-Japanese War end?", answers: ["1939", "1941", "1945", "1949"], correct: 2, fact: "Japan's surrender in 1945 ended the war, which had begun as a full-scale conflict in 1937.", source: "https://en.wikipedia.org/wiki/Second_Sino-Japanese_War" }
];

questions.push(...additionalQuestions);

const midCenturyQuestions = [
  { topic: "firstIndochina", category: "ideas", era: "modern", prompt: "Which two sides fought the First Indochina War?", answers: ["France and the Viet Minh", "China and Japan", "Britain and India", "Laos and Thailand"], correct: 0, fact: "The Viet Minh, led by the Democratic Republic of Vietnam, fought French forces from 1946 to 1954.", source: "https://en.wikipedia.org/wiki/First_Indochina_War" },
  { topic: "firstIndochina", category: "places", era: "modern", prompt: "Where did France suffer its decisive defeat in 1954 during the First Indochina War?", answers: ["Dien Bien Phu", "Hanoi", "Saigon", "Hue"], correct: 0, fact: "The Viet Minh victory at Dien Bien Phu in May 1954 helped bring French rule in Indochina to an end.", source: "https://en.wikipedia.org/wiki/First_Indochina_War" },
  { topic: "firstIndochina", category: "ideas", era: "modern", prompt: "Which 1954 international agreement helped end the First Indochina War?", answers: ["Geneva Accords", "Paris Peace Accords", "Tashkent Declaration", "Treaty of San Francisco"], correct: 0, fact: "The Geneva Conference agreements ended the fighting and provided for a temporary division of Vietnam near the 17th parallel.", source: "https://en.wikipedia.org/wiki/First_Indochina_War" },
  { topic: "firstIndochina", category: "places", era: "modern", prompt: "Which three countries emerged from the former French Indochina after the First Indochina War?", answers: ["Vietnam, Laos, and Cambodia", "Vietnam, Thailand, and Burma", "Laos, Cambodia, and Malaysia", "Vietnam, China, and Laos"], correct: 0, fact: "The Geneva settlement recognized the independence of Laos and Cambodia and set out a temporary division of Vietnam.", source: "https://en.wikipedia.org/wiki/First_Indochina_War" },

  { topic: "indiaPakistan1965", category: "ideas", era: "modern", prompt: "Which region was the central focus of the India–Pakistan War of 1965?", answers: ["Kashmir", "Punjab in Pakistan", "Bengal", "Sindh"], correct: 0, fact: "The 1965 war grew out of the dispute over Jammu and Kashmir, including Pakistan's Operation Gibraltar.", source: "https://en.wikipedia.org/wiki/India%E2%80%93Pakistan_war_of_1965" },
  { topic: "indiaPakistan1965", category: "ideas", era: "modern", prompt: "Which declaration helped bring the 1965 India–Pakistan War to a close?", answers: ["Tashkent Declaration", "Lahore Declaration", "Simla Agreement", "Geneva Accords"], correct: 0, fact: "India and Pakistan signed the Tashkent Declaration in January 1966 after a UN-backed ceasefire.", source: "https://en.wikipedia.org/wiki/India%E2%80%93Pakistan_war_of_1965" },
  { topic: "indiaPakistan1965", category: "places", era: "modern", prompt: "Which Indian tank battle in September 1965 became known for Pakistan's heavy tank losses?", answers: ["Asal Uttar", "Battle of Longewala", "Battle of Chawinda", "Battle of Haji Pir"], correct: 0, fact: "The Battle of Asal Uttar in Punjab was a major engagement of the war and included a large tank battle.", source: "https://en.wikipedia.org/wiki/India%E2%80%93Pakistan_war_of_1965" },
  { topic: "indiaPakistan1965", category: "ideas", era: "modern", prompt: "What was Operation Gibraltar, launched by Pakistan in 1965?", answers: ["An infiltration plan in Indian-administered Kashmir", "A naval blockade of Karachi", "An air campaign over Lahore", "A peace conference in Tashkent"], correct: 0, fact: "Operation Gibraltar sent infiltrators across the ceasefire line in an attempt to spark an uprising in Jammu and Kashmir.", source: "https://en.wikipedia.org/wiki/India%E2%80%93Pakistan_war_of_1965" },

  { topic: "sixDay", category: "ideas", era: "modern", prompt: "Between which dates was the Six-Day War fought in June 1967?", answers: ["5–10 June", "1–6 June", "10–15 June", "20–25 June"], correct: 0, fact: "The war lasted from 5 to 10 June 1967 and involved Israel, Egypt, Jordan, and Syria.", source: "https://en.wikipedia.org/wiki/Six-Day_War" },
  { topic: "sixDay", category: "places", era: "modern", prompt: "Which Egyptian territory did Israel capture during the Six-Day War?", answers: ["Sinai Peninsula", "Nile Delta", "Western Desert", "Libyan Desert"], correct: 0, fact: "Israel captured the Sinai Peninsula and Gaza Strip from Egypt during the war; it later returned Sinai to Egypt under a peace agreement.", source: "https://en.wikipedia.org/wiki/Six-Day_War" },
  { topic: "sixDay", category: "places", era: "modern", prompt: "Which Syrian territory did Israel capture in the final days of the Six-Day War?", answers: ["Golan Heights", "Bekaa Valley", "Sinai Peninsula", "Mount Lebanon"], correct: 0, fact: "Israeli forces captured the Golan Heights from Syria on 9–10 June 1967.", source: "https://en.wikipedia.org/wiki/Six-Day_War" },
  { topic: "sixDay", category: "ideas", era: "modern", prompt: "Which United Nations Security Council resolution called for Israeli withdrawal and a just, lasting peace after the Six-Day War?", answers: ["Resolution 242", "Resolution 181", "Resolution 338", "Resolution 194"], correct: 0, fact: "Adopted in November 1967, Resolution 242 became a key framework in later Arab–Israeli diplomacy.", source: "https://en.wikipedia.org/wiki/Six-Day_War" },

  { topic: "arabIsraeli", category: "ideas", era: "modern", prompt: "The 1948 Arab–Israeli War followed the end of which administration in Palestine?", answers: ["British Mandate", "French Mandate", "Ottoman occupation", "League of Nations trusteeship"], correct: 0, fact: "The British Mandate ended in May 1948, followed by the declaration of the State of Israel and war involving neighboring Arab states.", source: "https://en.wikipedia.org/wiki/Arab%E2%80%93Israeli_conflict" },
  { topic: "arabIsraeli", category: "ideas", era: "modern", prompt: "Which country became the first Arab state to sign a peace treaty with Israel, in 1979?", answers: ["Egypt", "Jordan", "Lebanon", "Syria"], correct: 0, fact: "The Egypt–Israel peace treaty followed the Camp David Accords and included Israel's withdrawal from the Sinai Peninsula.", source: "https://en.wikipedia.org/wiki/Arab%E2%80%93Israeli_conflict" },
  { topic: "arabIsraeli", category: "ideas", era: "modern", prompt: "What name is given to the Palestinian uprising that began in 1987?", answers: ["First Intifada", "Six-Day War", "Suez Crisis", "Black September"], correct: 0, fact: "The First Intifada was a Palestinian uprising in the occupied territories that began in December 1987.", source: "https://en.wikipedia.org/wiki/Arab%E2%80%93Israeli_conflict" },

  { topic: "koreanWar", category: "ideas", era: "modern", prompt: "When did North Korean forces cross the 38th parallel and invade South Korea?", answers: ["25 June 1950", "27 July 1953", "15 August 1945", "1 October 1949"], correct: 0, fact: "The invasion on 25 June 1950 began the Korean War.", source: "https://en.wikipedia.org/wiki/Korean_War" },
  { topic: "koreanWar", category: "places", era: "modern", prompt: "Which amphibious landing helped United Nations forces recapture Seoul in September 1950?", answers: ["Incheon landing", "Wonsan landing", "Busan landing", "Chosin landing"], correct: 0, fact: "The landing at Incheon, commanded by General Douglas MacArthur, outflanked North Korean forces around the Pusan Perimeter.", source: "https://en.wikipedia.org/wiki/Korean_War" },
  { topic: "koreanWar", category: "ideas", era: "modern", prompt: "What document halted large-scale fighting in the Korean War in July 1953?", answers: ["Korean Armistice Agreement", "Treaty of Seoul", "Peace Treaty of Panmunjom", "Geneva Convention"], correct: 0, fact: "The armistice was signed at Panmunjom on 27 July 1953; no peace treaty formally ended the war.", source: "https://en.wikipedia.org/wiki/Korean_War" },
  { topic: "koreanWar", category: "ideas", era: "modern", prompt: "Which country intervened militarily on North Korea's side in late 1950?", answers: ["China", "Japan", "India", "Australia"], correct: 0, fact: "Chinese forces entered the war in October 1950 and pushed UN forces back from areas near the Chinese border.", source: "https://en.wikipedia.org/wiki/Korean_War" },

  { topic: "algerianWar", category: "ideas", era: "modern", prompt: "Which organization led the Algerian struggle for independence from France?", answers: ["National Liberation Front (FLN)", "African National Congress", "Ba'ath Party", "Young Turks"], correct: 0, fact: "The FLN launched its independence campaign in 1954 and fought French rule until the 1962 ceasefire and independence.", source: "https://en.wikipedia.org/wiki/Algerian_War" },
  { topic: "algerianWar", category: "places", era: "modern", prompt: "Which city was the setting for a major urban insurgency and French counter-insurgency campaign in 1956–1957?", answers: ["Algiers", "Oran", "Tunis", "Casablanca"], correct: 0, fact: "The Battle of Algiers became one of the best-known episodes of the Algerian War.", source: "https://en.wikipedia.org/wiki/Algerian_War" },
  { topic: "algerianWar", category: "ideas", era: "modern", prompt: "Which 1962 agreements paved the way for Algerian independence?", answers: ["Évian Accords", "Treaty of Fez", "Camp David Accords", "Geneva Accords"], correct: 0, fact: "The Évian Accords established a ceasefire and led to a referendum and Algerian independence in 1962.", source: "https://en.wikipedia.org/wiki/Algerian_War" },
  { topic: "algerianWar", category: "ideas", era: "modern", prompt: "What name is often given to the coordinated attacks that began the Algerian War on 1 November 1954?", answers: ["Toussaint Rouge", "Battle of Algiers", "Sétif Uprising", "Week of Barricades"], correct: 0, fact: "The FLN launched attacks across Algeria on All Saints' Day 1954, marking the beginning of the war.", source: "https://en.wikipedia.org/wiki/Algerian_War" },

  { topic: "vietnamWar", category: "ideas", era: "modern", prompt: "Which 1968 campaign involved coordinated attacks by North Vietnamese and Viet Cong forces across South Vietnam?", answers: ["Tet Offensive", "Easter Offensive", "Operation Rolling Thunder", "Ho Chi Minh Campaign"], correct: 0, fact: "The Tet Offensive began during the Vietnamese Lunar New Year in 1968 and became a major turning point in U.S. public opinion.", source: "https://en.wikipedia.org/wiki/Vietnam_War" },
  { topic: "vietnamWar", category: "ideas", era: "modern", prompt: "Which 1973 agreement provided for a ceasefire and the withdrawal of U.S. forces from Vietnam?", answers: ["Paris Peace Accords", "Geneva Accords", "Tashkent Declaration", "Camp David Accords"], correct: 0, fact: "The Paris Peace Accords were signed in January 1973; major fighting in Vietnam continued afterward.", source: "https://en.wikipedia.org/wiki/Vietnam_War" },
  { topic: "vietnamWar", category: "places", era: "modern", prompt: "Which South Vietnamese city fell to North Vietnamese forces on 30 April 1975?", answers: ["Saigon", "Hue", "Da Nang", "Hanoi"], correct: 0, fact: "The fall of Saigon marked the end of the Vietnam War and the reunification of Vietnam under communist rule.", source: "https://en.wikipedia.org/wiki/Vietnam_War" },
  { topic: "vietnamWar", category: "people", era: "modern", prompt: "Who was the president of North Vietnam for most of the Vietnam War and a central figure in its independence movement?", answers: ["Ho Chi Minh", "Ngo Dinh Diem", "Bao Dai", "Pol Pot"], correct: 0, fact: "Ho Chi Minh led the Viet Minh and later the Democratic Republic of Vietnam until his death in 1969.", source: "https://en.wikipedia.org/wiki/Vietnam_War" },

  { topic: "sinoIndian", category: "places", era: "modern", prompt: "Which two areas were the main disputed fronts in the 1962 Sino-Indian War?", answers: ["Aksai Chin and the eastern Himalayan frontier", "Kashmir and Punjab", "Tibet and Taiwan", "Sikkim and Nepal"], correct: 0, fact: "The dispute centered on Aksai Chin in the west and the McMahon Line area in the eastern sector.", source: "https://en.wikipedia.org/wiki/Sino-Indian_War" },
  { topic: "sinoIndian", category: "ideas", era: "modern", prompt: "Which country declared a unilateral ceasefire in the Sino-Indian War in November 1962?", answers: ["China", "India", "Pakistan", "Burma"], correct: 0, fact: "China announced a unilateral ceasefire on 21 November 1962 and withdrew from parts of the eastern sector.", source: "https://en.wikipedia.org/wiki/Sino-Indian_War" },
  { topic: "sinoIndian", category: "ideas", era: "modern", prompt: "What disputed boundary line was a central point of contention in the eastern sector of the Sino-Indian War?", answers: ["McMahon Line", "Durand Line", "Radcliffe Line", "Line of Control"], correct: 0, fact: "India regarded the McMahon Line as the international border in the eastern sector; China rejected it.", source: "https://en.wikipedia.org/wiki/Sino-Indian_War" },

  { topic: "sovietAfghan", category: "ideas", era: "modern", prompt: "When did Soviet troops begin their large-scale intervention in Afghanistan?", answers: ["December 1979", "April 1978", "May 1988", "February 1989"], correct: 0, fact: "The Soviet Union invaded Afghanistan in December 1979 to support the allied Afghan government amid a growing insurgency.", source: "https://en.wikipedia.org/wiki/Soviet%E2%80%93Afghan_War" },
  { topic: "sovietAfghan", category: "ideas", era: "modern", prompt: "Which Afghan resistance fighters battled Soviet forces during the Soviet–Afghan War?", answers: ["Mujahideen", "Contras", "Basmachi only", "Young Turks"], correct: 0, fact: "Various Afghan mujahideen groups fought the Soviet-backed government and Soviet troops, receiving support from several foreign states.", source: "https://en.wikipedia.org/wiki/Soviet%E2%80%93Afghan_War" },
  { topic: "sovietAfghan", category: "ideas", era: "modern", prompt: "Which 1988 agreements set a timetable for Soviet withdrawal from Afghanistan?", answers: ["Geneva Accords", "Camp David Accords", "Tashkent Declaration", "Helsinki Accords"], correct: 0, fact: "The Geneva Accords were signed in April 1988, and the final Soviet troops left Afghanistan in February 1989.", source: "https://en.wikipedia.org/wiki/Soviet%E2%80%93Afghan_War" },

  { topic: "iranIraq", category: "ideas", era: "modern", prompt: "Which country launched the invasion that began the Iran–Iraq War in September 1980?", answers: ["Iraq", "Iran", "Kuwait", "Saudi Arabia"], correct: 0, fact: "Iraq invaded Iran on 22 September 1980; the war continued until a ceasefire in 1988.", source: "https://en.wikipedia.org/wiki/Iran%E2%80%93Iraq_War" },
  { topic: "iranIraq", category: "places", era: "modern", prompt: "Which strategic waterway at the head of the Persian Gulf was a recurring point of dispute during the Iran–Iraq War?", answers: ["Shatt al-Arab", "Suez Canal", "Strait of Hormuz", "Bab-el-Mandeb"], correct: 0, fact: "The Shatt al-Arab waterway and its boundary were central to longstanding tensions between Iran and Iraq.", source: "https://en.wikipedia.org/wiki/Iran%E2%80%93Iraq_War" },
  { topic: "iranIraq", category: "ideas", era: "modern", prompt: "Which UN Security Council resolution was central to the ceasefire that ended the Iran–Iraq War?", answers: ["Resolution 598", "Resolution 242", "Resolution 181", "Resolution 338"], correct: 0, fact: "Iran accepted Resolution 598 in 1988, and a ceasefire took effect on 20 August 1988.", source: "https://en.wikipedia.org/wiki/Iran%E2%80%93Iraq_War" },

  { topic: "falklands", category: "ideas", era: "modern", prompt: "Which two countries fought the Falklands War in 1982?", answers: ["United Kingdom and Argentina", "Chile and Argentina", "United Kingdom and Spain", "Brazil and Uruguay"], correct: 0, fact: "Argentina invaded the Falkland Islands in April 1982; the United Kingdom sent a task force to retake them.", source: "https://en.wikipedia.org/wiki/Falklands_War" },
  { topic: "falklands", category: "places", era: "modern", prompt: "What is the Argentine name for the Falkland Islands?", answers: ["Islas Malvinas", "Tierra del Fuego", "Islas Georgias", "Patagonia"], correct: 0, fact: "Argentina calls the islands Islas Malvinas and claims sovereignty over them; the United Kingdom also claims sovereignty.", source: "https://en.wikipedia.org/wiki/Falklands_War" },
  { topic: "falklands", category: "people", era: "modern", prompt: "Which British prime minister led the United Kingdom during the Falklands War?", answers: ["Margaret Thatcher", "Harold Wilson", "John Major", "Edward Heath"], correct: 0, fact: "Margaret Thatcher was prime minister when British forces retook the islands in June 1982.", source: "https://en.wikipedia.org/wiki/Falklands_War" },
  { topic: "falklands", category: "places", era: "modern", prompt: "Where did Argentine forces surrender on 14 June 1982, ending the main fighting in the Falklands War?", answers: ["Stanley", "Port Darwin", "Goose Green", "South Georgia"], correct: 0, fact: "The Argentine garrison in Stanley surrendered on 14 June 1982, ending the 74-day conflict.", source: "https://en.wikipedia.org/wiki/Falklands_War" }
];

questions.push(...midCenturyQuestions);

const recentConflictQuestions = [
  { topic: "gulfWar1991", category: "places", era: "modern", prompt: "Which country did Iraq invade on 2 August 1990, triggering the Gulf crisis?", answers: ["Kuwait", "Iran", "Saudi Arabia", "Bahrain"], correct: 0, fact: "Iraqi forces invaded Kuwait in August 1990. A U.S.-led coalition later expelled Iraqi forces in 1991.", source: "https://en.wikipedia.org/wiki/Gulf_War" },
  { topic: "gulfWar1991", category: "ideas", era: "modern", prompt: "What was the name of the coalition operation that initially deployed forces to defend Saudi Arabia?", answers: ["Operation Desert Shield", "Operation Desert Storm", "Operation Iraqi Freedom", "Operation Southern Watch"], correct: 0, fact: "Operation Desert Shield began in August 1990 to deter an Iraqi advance into Saudi Arabia.", source: "https://en.wikipedia.org/wiki/Gulf_War" },
  { topic: "gulfWar1991", category: "ideas", era: "modern", prompt: "Which operation began the coalition air campaign against Iraq on 17 January 1991?", answers: ["Operation Desert Storm", "Operation Desert Shield", "Operation Provide Comfort", "Operation Enduring Freedom"], correct: 0, fact: "Operation Desert Storm began with a large air campaign, followed by a ground offensive in February.", source: "https://en.wikipedia.org/wiki/Gulf_War" },
  { topic: "gulfWar1991", category: "ideas", era: "modern", prompt: "What was the main military outcome of the 1991 Gulf War?", answers: ["Kuwait was liberated from Iraqi occupation", "Iraq annexed Saudi Arabia", "Iran occupied Kuwait", "The United Nations dissolved Iraq"], correct: 0, fact: "Coalition forces drove Iraqi troops out of Kuwait and ended active hostilities in February 1991.", source: "https://en.wikipedia.org/wiki/Gulf_War" },
  { topic: "gulfWar1991", category: "places", era: "modern", prompt: "Which small Gulf monarchy was occupied by Iraq before the 1991 coalition campaign?", answers: ["Kuwait", "Qatar", "Oman", "Bahrain"], correct: 0, fact: "The invasion and occupation of Kuwait was the immediate trigger for the Gulf War.", source: "https://en.wikipedia.org/wiki/Gulf_War" },

  { topic: "yugoslavWars", category: "ideas", era: "modern", prompt: "What major political process were the Yugoslav Wars fought amid?", answers: ["The breakup of Yugoslavia", "The unification of Germany", "The partition of India", "The dissolution of the Ottoman Empire"], correct: 0, fact: "The wars accompanied the breakup of the Socialist Federal Republic of Yugoslavia and the emergence of successor states.", source: "https://en.wikipedia.org/wiki/Yugoslav_Wars" },
  { topic: "yugoslavWars", category: "places", era: "modern", prompt: "Which newly independent republic fought the brief Ten-Day War in 1991?", answers: ["Slovenia", "Bosnia and Herzegovina", "Macedonia", "Montenegro"], correct: 0, fact: "Slovenia's Ten-Day War followed its declaration of independence from Yugoslavia in June 1991.", source: "https://en.wikipedia.org/wiki/Yugoslav_Wars" },
  { topic: "yugoslavWars", category: "ideas", era: "modern", prompt: "Which 1995 agreement brought the Bosnian War to an end?", answers: ["Dayton Peace Agreement", "Treaty of Maastricht", "Rambouillet Agreement", "Belgrade Declaration"], correct: 0, fact: "The Dayton Peace Agreement was negotiated in 1995 and established the postwar framework for Bosnia and Herzegovina.", source: "https://en.wikipedia.org/wiki/Yugoslav_Wars" },
  { topic: "yugoslavWars", category: "places", era: "modern", prompt: "Which city was under siege for nearly four years during the Bosnian War?", answers: ["Sarajevo", "Zagreb", "Belgrade", "Ljubljana"], correct: 0, fact: "The Siege of Sarajevo lasted from 1992 until 1996 and became one of the defining episodes of the Bosnian War.", source: "https://en.wikipedia.org/wiki/Yugoslav_Wars" },
  { topic: "yugoslavWars", category: "ideas", era: "modern", prompt: "Which conflict in the Yugoslav Wars took place mainly in 1998–1999?", answers: ["Kosovo War", "Ten-Day War", "Croatian War of Independence", "Bosnian War"], correct: 0, fact: "The Kosovo War was fought from 1998 to 1999, followed by an international administration of Kosovo.", source: "https://en.wikipedia.org/wiki/Yugoslav_Wars" },

  { topic: "congoWars", category: "ideas", era: "modern", prompt: "Which Congolese conflict from 1996 to 1997 led to the overthrow of Mobutu Sese Seko?", answers: ["First Congo War", "Second Congo War", "Congo Crisis", "Shaba II"], correct: 0, fact: "The First Congo War ended Mobutu's rule and brought Laurent-Désiré Kabila to power.", source: "https://en.wikipedia.org/wiki/Congolese_Civil_War" },
  { topic: "congoWars", category: "people", era: "modern", prompt: "Which leader became president of the Democratic Republic of the Congo after the First Congo War?", answers: ["Laurent-Désiré Kabila", "Mobutu Sese Seko", "Patrice Lumumba", "Joseph Kasa-Vubu"], correct: 0, fact: "Laurent-Désiré Kabila's forces captured Kinshasa in 1997 after Mobutu fled the country.", source: "https://en.wikipedia.org/wiki/Congolese_Civil_War" },
  { topic: "congoWars", category: "ideas", era: "modern", prompt: "Which war in the Democratic Republic of the Congo lasted from 1998 to 2003 and involved nine nations?", answers: ["Second Congo War", "First Congo War", "Congo Crisis", "Kongo Civil War"], correct: 0, fact: "The Second Congo War drew in multiple African states and is sometimes called the Great African War.", source: "https://en.wikipedia.org/wiki/Congolese_Civil_War" },
  { topic: "congoWars", category: "places", era: "modern", prompt: "In which present-day country did the First and Second Congo Wars primarily take place?", answers: ["Democratic Republic of the Congo", "Republic of the Congo", "Central African Republic", "Angola"], correct: 0, fact: "The linked overview distinguishes conflicts in the Democratic Republic of the Congo from civil wars in the neighboring Republic of the Congo.", source: "https://en.wikipedia.org/wiki/Congolese_Civil_War" },
  { topic: "congoWars", category: "ideas", era: "modern", prompt: "What major political milestone followed the official end of the Second Congo War?", answers: ["The DRC's first democratic elections in 2006", "The restoration of Mobutu", "The annexation of Rwanda", "The dissolution of the United Nations"], correct: 0, fact: "Although the war officially ended in 2003, the linked overview notes that the DRC held its first democratic elections in 2006 amid continued low-level conflict.", source: "https://en.wikipedia.org/wiki/Congolese_Civil_War" },

  { topic: "kargilWar", category: "ideas", era: "modern", prompt: "Which two countries fought the Kargil War in 1999?", answers: ["India and Pakistan", "India and China", "Pakistan and Afghanistan", "China and Nepal"], correct: 0, fact: "The Kargil War was fought between India and Pakistan in the Kashmir region from May to July 1999.", source: "https://en.wikipedia.org/wiki/Kargil_War" },
  { topic: "kargilWar", category: "places", era: "modern", prompt: "In which district did the 1999 Kargil War take place?", answers: ["Kargil district", "Srinagar district", "Lahore district", "Gilgit district"], correct: 0, fact: "The fighting occurred in the high-altitude Kargil district, now part of India's Ladakh region.", source: "https://en.wikipedia.org/wiki/Kargil_War" },
  { topic: "kargilWar", category: "ideas", era: "modern", prompt: "What name did India give to its military operation to regain positions during the Kargil War?", answers: ["Operation Vijay", "Operation Gibraltar", "Operation Meghdoot", "Operation Safed Sagar"], correct: 0, fact: "Operation Vijay was the Indian Army operation; the Indian Air Force's supporting campaign was called Operation Safed Sagar.", source: "https://en.wikipedia.org/wiki/Kargil_War" },
  { topic: "kargilWar", category: "places", era: "modern", prompt: "Which famous peak was recaptured by Indian forces near the end of the Kargil War?", answers: ["Tiger Hill", "Nanda Devi", "K2", "Nanga Parbat"], correct: 0, fact: "The capture of Tiger Hill was one of the best-known Indian military successes in the conflict.", source: "https://en.wikipedia.org/wiki/Kargil_War" },
  { topic: "kargilWar", category: "ideas", era: "modern", prompt: "On which date did the Kargil War end, commemorated in India as Kargil Vijay Diwas?", answers: ["26 July 1999", "15 August 1999", "3 May 1999", "14 June 1999"], correct: 0, fact: "The conflict ended on 26 July 1999 after India regained control of the positions it had lost.", source: "https://en.wikipedia.org/wiki/Kargil_War" },

  { topic: "afghanistan2001", category: "ideas", era: "modern", prompt: "Which attacks in 2001 preceded the U.S.-led invasion of Afghanistan?", answers: ["September 11 attacks", "1998 embassy bombings", "2004 Madrid train bombings", "2005 London bombings"], correct: 0, fact: "The United States and its allies invaded Afghanistan in October 2001 after the September 11 attacks and the Taliban government's refusal to hand over al-Qaeda leaders.", source: "https://en.wikipedia.org/wiki/War_in_Afghanistan" },
  { topic: "afghanistan2001", category: "people", era: "modern", prompt: "Which movement's government was removed from power in Afghanistan in 2001?", answers: ["The Taliban", "The Mujahideen", "The Northern Alliance", "The Durrani dynasty"], correct: 0, fact: "The Taliban government was overthrown in late 2001, though the movement later launched an insurgency.", source: "https://en.wikipedia.org/wiki/War_in_Afghanistan" },
  { topic: "afghanistan2001", category: "ideas", era: "modern", prompt: "Which NATO-led mission took over command of international security forces in Afghanistan in 2003?", answers: ["ISAF", "KFOR", "UNPROFOR", "Operation Desert Storm"], correct: 0, fact: "The International Security Assistance Force (ISAF) was authorized by the UN and came under NATO command in 2003.", source: "https://en.wikipedia.org/wiki/War_in_Afghanistan" },
  { topic: "afghanistan2001", category: "ideas", era: "modern", prompt: "Which 2020 agreement set a timetable for U.S. troop withdrawal from Afghanistan?", answers: ["Doha Agreement", "Geneva Accords", "Dayton Agreement", "Tashkent Declaration"], correct: 0, fact: "The United States and the Taliban signed the Doha Agreement in February 2020.", source: "https://en.wikipedia.org/wiki/War_in_Afghanistan" },
  { topic: "afghanistan2001", category: "places", era: "modern", prompt: "Which Afghan capital fell to the Taliban in August 2021 as the U.S.-led war ended?", answers: ["Kabul", "Kandahar", "Herat", "Mazar-i-Sharif"], correct: 0, fact: "The Taliban entered Kabul on 15 August 2021, shortly before the final U.S. withdrawal.", source: "https://en.wikipedia.org/wiki/War_in_Afghanistan" },

  { topic: "iraqWar2003", category: "ideas", era: "modern", prompt: "In which year did the U.S.-led invasion of Iraq begin?", answers: ["2001", "2003", "2005", "2008"], correct: 1, fact: "The invasion began in March 2003, led by a coalition including the United States and the United Kingdom.", source: "https://en.wikipedia.org/wiki/Iraq_War" },
  { topic: "iraqWar2003", category: "places", era: "modern", prompt: "Which Iraqi capital city was captured by coalition forces in April 2003?", answers: ["Baghdad", "Basra", "Mosul", "Tikrit"], correct: 0, fact: "Baghdad fell to coalition forces in April 2003, during the initial invasion phase.", source: "https://en.wikipedia.org/wiki/Iraq_War" },
  { topic: "iraqWar2003", category: "people", era: "modern", prompt: "Which Iraqi president was captured by U.S. forces near Tikrit in December 2003?", answers: ["Saddam Hussein", "Nouri al-Maliki", "Ahmed Hassan al-Bakr", "Jalal Talabani"], correct: 0, fact: "Saddam Hussein was captured in December 2003 and was later tried and executed by the Iraqi government.", source: "https://en.wikipedia.org/wiki/Iraq_War" },
  { topic: "iraqWar2003", category: "ideas", era: "modern", prompt: "In which year did U.S. forces complete their withdrawal from Iraq under the 2008 security agreement?", answers: ["2008", "2009", "2011", "2014"], correct: 2, fact: "The United States completed its withdrawal in December 2011, though conflict and insurgency continued afterward.", source: "https://en.wikipedia.org/wiki/Iraq_War" },
  { topic: "iraqWar2003", category: "ideas", era: "modern", prompt: "Which weapons issue was a central public justification for the 2003 invasion, but no active stockpiles were found by postwar inspections?", answers: ["Weapons of mass destruction", "Nuclear weapons used in combat", "Chemical weapons used against coalition troops", "Biological weapons used in Kuwait"], correct: 0, fact: "The search after the invasion did not find the active Iraqi stockpiles of weapons of mass destruction cited in the case for war.", source: "https://en.wikipedia.org/wiki/Iraq_War" },

  { topic: "russoGeorgian", category: "ideas", era: "modern", prompt: "In which year was the Russo-Georgian War fought?", answers: ["1998", "2003", "2008", "2014"], correct: 2, fact: "The war took place in August 2008 and involved Georgia, Russia, South Ossetian forces, and Abkhaz forces.", source: "https://en.wikipedia.org/wiki/Russo-Georgian_War" },
  { topic: "russoGeorgian", category: "places", era: "modern", prompt: "Which breakaway region was the site of the Battle of Tskhinvali in August 2008?", answers: ["South Ossetia", "Adjara", "Nagorno-Karabakh", "Chechnya"], correct: 0, fact: "Tskhinvali is the principal city of South Ossetia, one of the disputed regions at the center of the war.", source: "https://en.wikipedia.org/wiki/Russo-Georgian_War" },
  { topic: "russoGeorgian", category: "people", era: "modern", prompt: "Which French president helped broker the six-point ceasefire plan during the Russo-Georgian War?", answers: ["Nicolas Sarkozy", "Jacques Chirac", "François Hollande", "Emmanuel Macron"], correct: 0, fact: "French president Nicolas Sarkozy mediated the six-point ceasefire agreement in August 2008.", source: "https://en.wikipedia.org/wiki/Russo-Georgian_War" },
  { topic: "russoGeorgian", category: "places", era: "modern", prompt: "Which Georgian city was bombed and occupied by Russian forces during the 2008 war?", answers: ["Gori", "Batumi", "Kutaisi", "Rustavi"], correct: 0, fact: "Russian forces bombed and occupied Gori during the brief August 2008 conflict.", source: "https://en.wikipedia.org/wiki/Russo-Georgian_War" },
  { topic: "russoGeorgian", category: "ideas", era: "modern", prompt: "Which two territories did Russia recognize as independent after the Russo-Georgian War?", answers: ["Abkhazia and South Ossetia", "Ajaria and Svaneti", "Chechnya and Dagestan", "Crimea and Donbas"], correct: 0, fact: "Russia recognized Abkhazia and South Ossetia after the ceasefire; Georgia and most countries regard them as part of Georgia.", source: "https://en.wikipedia.org/wiki/Russo-Georgian_War" },

  { topic: "syrianCivil", category: "ideas", era: "modern", prompt: "In which year did protests that escalated into the Syrian Civil War begin?", answers: ["2003", "2008", "2011", "2015"], correct: 2, fact: "Protests began in 2011 during the Arab Spring and developed into a nationwide uprising and armed conflict.", source: "https://en.wikipedia.org/wiki/Syrian_civil_war" },
  { topic: "syrianCivil", category: "places", era: "modern", prompt: "Which southern Syrian city saw early 2011 protests that helped spark the uprising?", answers: ["Daraa", "Aleppo", "Latakia", "Palmyra"], correct: 0, fact: "Demonstrations in Daraa in March 2011 were an early flashpoint in the Syrian uprising.", source: "https://en.wikipedia.org/wiki/Syrian_civil_war" },
  { topic: "syrianCivil", category: "people", era: "modern", prompt: "Who was Syria's president when the uprising began in 2011?", answers: ["Bashar al-Assad", "Hafez al-Assad", "Nouri al-Maliki", "Mahmoud Abbas"], correct: 0, fact: "Bashar al-Assad was president at the start of the war; his government fell in December 2024.", source: "https://en.wikipedia.org/wiki/Syrian_civil_war" },
  { topic: "syrianCivil", category: "ideas", era: "modern", prompt: "Which country's military intervention in 2015 provided major support to the Syrian government?", answers: ["Russia", "Brazil", "Japan", "Canada"], correct: 0, fact: "Russia began a military intervention in Syria in September 2015, supporting the Assad government.", source: "https://en.wikipedia.org/wiki/Syrian_civil_war" },
  { topic: "syrianCivil", category: "ideas", era: "modern", prompt: "Which major political change occurred in Syria in December 2024?", answers: ["The Assad regime fell", "The country joined NATO", "The civil war began", "Syria reunified with Lebanon"], correct: 0, fact: "The Assad regime fell in December 2024, opening a new transitional period in Syria.", source: "https://en.wikipedia.org/wiki/Syrian_civil_war" }
];

questions.push(...recentConflictQuestions);

const eraNames = { ancient: "ANCIENT WORLD", medieval: "MIDDLE AGES", "early-modern": "EARLY MODERN", modern: "MODERN AGE" };
const categoryNames = { people: "PEOPLE", places: "PLACES", ideas: "IDEAS" };
let category = "all";
let era = "all";
let topic = "all";
let round = [];
let index = 0;
let selected = null;
let checked = false;
let score = 0;
let roundCorrect = 0;
let finished = false;

const questionText = document.querySelector("#question-text");
const answersEl = document.querySelector("#answers");
const nextButton = document.querySelector("#next-button");
const skipButton = document.querySelector("#skip-button");
const feedbackEl = document.querySelector("#feedback");
const topicFilter = document.querySelector("#topic-filter");

topicNames.napoleonic = "Napoleonic Wars";
topicNames.worldWarOne = "World War I";
topicNames.worldWarTwo = "World War II";
topicNames.general = "General history";
const topicForQuestion = q => {
  if (q.topic) return q.topic;
  if (q.source?.includes("Napoleonic_Wars")) return "napoleonic";
  if (q.source?.includes("World_War_I")) return "worldWarOne";
  if (q.source?.includes("World_War_II")) return "worldWarTwo";
  return "general";
};
for (const [key, label] of Object.entries(topicNames)) {
  const option = document.createElement("option");
  option.value = key;
  option.textContent = label;
  topicFilter.append(option);
}

function availableQuestions() {
  return questions.filter(q => (category === "all" || q.category === category) && (era === "all" || q.era === era) && (topic === "all" || topicForQuestion(q) === topic));
}

function startRound() {
  const pool = availableQuestions();
  finished = false;
  nextButton.onclick = null;
  if (!pool.length) {
    round = [];
    document.querySelector("#round-length").textContent = "No questions";
    document.querySelector("#round-duration").textContent = "Choose another filter";
    questionText.textContent = "No stories in this combination just yet.";
    document.querySelector("#question-count").innerHTML = "PICK ANOTHER PATH";
    document.querySelector("#question-category").innerHTML = "✦ &nbsp; MORE STORIES COMING SOON";
    document.querySelector("#era-badge").textContent = "";
    document.querySelector("#progress-fill").style.width = "0%";
    answersEl.replaceChildren();
    feedbackEl.hidden = true;
    nextButton.disabled = true;
    skipButton.hidden = true;
    return;
  }
  roundCorrect = 0;
  const shuffled = [...pool];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  round = shuffled.slice(0, Math.min(5, shuffled.length));
  document.querySelector("#round-length").textContent = `${round.length} questions`;
  document.querySelector("#round-duration").textContent = `About ${round.length < 5 ? "1" : "2"} minutes`;
  index = 0;
  renderQuestion();
}

function renderQuestion() {
  selected = null;
  checked = false;
  const q = round[index];
  const number = String(index + 1).padStart(2, "0");
  const progressTrack = document.querySelector(".progress-track");
  progressTrack.setAttribute("aria-valuemax", String(round.length));
  progressTrack.setAttribute("aria-valuenow", String(index + 1));
  document.querySelector("#question-count").innerHTML = `QUESTION ${number} <span>/ ${String(round.length).padStart(2, "0")}</span>`;
  document.querySelector("#progress-fill").style.width = `${((index + 1) / round.length) * 100}%`;
  document.querySelector("#era-badge").textContent = eraNames[q.era];
  document.querySelector("#question-category").innerHTML = `✦ &nbsp; ${categoryNames[q.category]}`;
  questionText.textContent = q.prompt;
  answersEl.replaceChildren(...q.answers.map((answer, i) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "answer-option";
    button.setAttribute("aria-pressed", "false");
    button.innerHTML = `<span class="letter">${String.fromCharCode(65 + i)}</span><span>${answer}</span>`;
    button.addEventListener("click", () => chooseAnswer(i));
    return button;
  }));
  feedbackEl.hidden = true;
  feedbackEl.textContent = "";
  nextButton.disabled = true;
  nextButton.innerHTML = 'Check answer <span>↗</span>';
  skipButton.hidden = false;
}

function chooseAnswer(choice) {
  if (checked) return;
  selected = choice;
  [...answersEl.children].forEach((button, i) => {
    button.classList.toggle("selected", i === choice);
    button.setAttribute("aria-pressed", String(i === choice));
  });
  nextButton.disabled = false;
}

function checkAnswer() {
  if (selected === null || checked) return;
  checked = true;
  const q = round[index];
  const correct = selected === q.correct;
  if (correct) { score += 10; roundCorrect++; }
  document.querySelector("#score-count").textContent = score;
  [...answersEl.children].forEach((button, i) => {
    button.disabled = true;
    if (i === q.correct) button.classList.add("correct");
    else if (i === selected) button.classList.add("wrong");
  });
  feedbackEl.innerHTML = `<strong>${correct ? "That’s right!" : `The answer is ${q.answers[q.correct]}.`}</strong> ${q.fact}${q.source ? ` <a class="source-link" href="${q.source}" target="_blank" rel="noreferrer">Read source ↗</a>` : ""}`;
  feedbackEl.hidden = false;
  nextButton.innerHTML = index === round.length - 1 ? 'See your results <span>↗</span>' : 'Next question <span>↗</span>';
}

function advance() {
  if (finished) return startRound();
  if (!checked) return checkAnswer();
  if (index < round.length - 1) {
    index++;
    renderQuestion();
    return;
  }
  finished = true;
  questionText.textContent = roundCorrect >= round.length * 0.8 ? "A remarkable memory for the past." : roundCorrect >= round.length * 0.4 ? "A curious mind is a growing mind." : "Every great historian starts somewhere.";
  document.querySelector("#question-category").innerHTML = "✦ &nbsp; YOUR RESULTS";
  document.querySelector("#era-badge").textContent = `${roundCorrect} OF ${round.length} RIGHT`;
  answersEl.replaceChildren();
  feedbackEl.innerHTML = `<strong>Round complete.</strong> You earned ${roundCorrect * 10} points. Choose a path above to play again.`;
  feedbackEl.hidden = false;
  document.querySelector("#question-count").innerHTML = `A GOOD RUN <span>/ ${round.length}</span>`;
  document.querySelector("#progress-fill").style.width = "100%";
  document.querySelector(".progress-track").setAttribute("aria-valuenow", String(round.length));
  nextButton.innerHTML = 'Play again <span>↗</span>';
  nextButton.disabled = false;
  skipButton.hidden = true;
}

nextButton.addEventListener("click", advance);
skipButton.addEventListener("click", () => {
  if (!round.length) return;
  selected = null;
  checked = true;
  advance();
});
document.querySelector("#category-filters").addEventListener("click", event => {
  const button = event.target.closest("[data-filter]");
  if (!button) return;
  category = button.dataset.value;
  document.querySelectorAll("[data-filter='category']").forEach(chip => {
    const active = chip === button;
    chip.classList.toggle("active", active);
    chip.setAttribute("aria-pressed", String(active));
  });
  startRound();
});
document.querySelector("#era-filter").addEventListener("change", event => { era = event.target.value; startRound(); });
topicFilter.addEventListener("change", event => { topic = event.target.value; startRound(); });

startRound();
